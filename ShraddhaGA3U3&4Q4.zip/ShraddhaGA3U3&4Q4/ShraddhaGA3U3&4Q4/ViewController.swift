//
//  ViewController.swift
//  ShraddhaGA3U3&4Q4
//
//  Created by Jiaying Cui on 2019-05-20.
//  Copyright © 2019 Jiaying Cui. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var result: UITextField!
    @IBAction func No(_ sender: Any) {
        result.text = "Great! you are correct"
        
    }
    
    
    
    @IBAction func yes(_ sender: Any) {
        result.text = "Sorry! You are wrong"
    }
    
    
    
}

