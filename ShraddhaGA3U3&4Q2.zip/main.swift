/*shraddha Gourishetty
*Assignment 3
*Unit 3 & 4
*Question 2
*Date 09/05/19
*/

var number = [Double]() //empty array
var positivearray = [Int]() //empty array for positive numbers 
var negativearray = [Double]() //empty array for negative numbers 
var double = [Double]() //empty array for double numbers 

//Displaying user some instructions
print("Enter a few numbers with the combination of positive numbers, negative numbers and including decimals") 
print("How many numbers you wnat to enter?")
let userenterednumber = Int(readLine()!) //reading userinput

print("Now, Enter the number with the combination of positives, negatives and decimals") // Asking user to enter some numbers
//iterrative loop to add all the userinput to the empty array
for _ in 1...(userenterednumber!)
{
  let userinput = Double(readLine()!)
  number.append(userinput!)
}

// To sort the numbers in the array in order
print("The numbers which you have entered in decending order are:")

number.sort {
  return $0 > $1
}
print(number)


//Sorting the the negative numbers in the array
let negativenumber = number.first(where: { $0 < 0})
negativearray.append(negativenumber!)
print("Negative numbers are:")
print(negativearray)

//Sorting the positive numbers in the array
let positivenumber = number.first(where: { $0 > 0})
let integer = Int(positivenumber!)
positivearray.append(integer)
print("Positive numbers are:")
print(positivearray)

//Sorting the double numbers in the array
number = number.filter{$0 != positivenumber}
number = number.filter{$0 != negativenumber}
print("Decimal numbers are:")
print(number)
