/*Shraddha Gourishetty
* Assignment 3
* Unit 3 & 4
* Question 3
* Date: 10/05/19
*/

package com.example.tipcalculator;

//Import statemnets
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    
    //Declaring the variables
    private EditText billAmountEditText;
    private SeekBar mSeekBar;
    private TextView seekbarTextView;
    private Button calButton;
    private TextView tipTextView;
    private TextView totalTextView;
    private int seekbarPercentage;
    private Float billAmount;

//Create a function to calculate the tip amount based on the bill and the tip percentage
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        billAmountEditText = findViewById(R.id.billAmountEditText_id);
        mSeekBar = findViewById(R.id.seekBar_id);
        seekbarTextView = findViewById(R.id.seekbarTextView_id);
        calButton = findViewById(R.id.calButton_id);
        tipTextView = findViewById(R.id.tipTextView_id);
        totalTextView = findViewById(R.id.totalTextView_id);

        seekbarTextView.setText(String.valueOf(mSeekBar.getProgress()) + "%");
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekbarTextView.setText(String.valueOf(mSeekBar.getProgress()) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                seekbarPercentage = mSeekBar.getProgress();

            }
        });

        calButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
            }
        });
    }

    //calculate the total bill amount
    public void calculate(){
        Float result = 0.0f;

        if (!billAmountEditText.getText().toString().equals("")){
            billAmount = Float.parseFloat(billAmountEditText.getText().toString());
            result = billAmount * seekbarPercentage /100;
            tipTextView.setText("Tip: $" + String.valueOf(result));
            totalTextView.setText("Total Amount: $" + (billAmount+result));
        }

        else{
            Toast.makeText(this,  "Please enter bill amount", Toast.LENGTH_SHORT).show();

        }
    }
}
